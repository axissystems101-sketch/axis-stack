# Cron Job Templates
# ⚡ AXIS STACK — 5 Ready-to-Use Automations
#
# Install these with: openclaw cron add --name "NAME" --cron "SCHEDULE" --message "PROMPT"

## 1. Morning Briefing (Daily 9 AM)
**Schedule:** `0 9 * * *`
**Model:** gemini-3-flash (cheap)
**Prompt:**
```
Check email for urgent messages. Check calendar for today's events. 
Summarize the top 3 priorities for today based on MEMORY.md and recent daily logs.
Send a brief morning briefing.
```

## 2. Market Radar (Every 6 Hours)  
**Schedule:** `0 */6 * * *`
**Model:** gemini-3-flash
**Prompt:**
```
Search Reddit and X for people struggling with AI agent setups.
Classify findings as Hot Leads, Market Gaps, Trends, or Opportunities.
Write results to business/market-radar.md.
```

## 3. Lead Scanner (Daily 12 PM)
**Schedule:** `0 12 * * *`
**Model:** gemini-3-flash
**Prompt:**
```
Search Reddit (r/openclaw, r/aiagents, r/entrepreneur) for posts 
where people are asking for help with AI automation.
Log potential leads to business/pipeline.md.
```

## 4. Content Ideas (Daily 2 PM)
**Schedule:** `0 14 * * *`
**Model:** gemini-3-flash
**Prompt:**
```
Based on today's market research and recent trends, suggest 3 content 
ideas for Substack/social media. Focus on topics people are actively 
searching for. Write suggestions to business/content-ideas.md.
```

## 5. Weekly Review (Monday 8 PM)
**Schedule:** `0 20 * * 1`
**Model:** gemini-3-flash
**Prompt:**
```
Review this week's progress. Check: revenue, leads generated, content 
published, system health. Compare to goals in SOUL.md. Write a weekly 
report with honest assessment and recommendations for next week.
```
