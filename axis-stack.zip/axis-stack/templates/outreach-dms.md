# Outreach DM Templates
# ⚡ AXIS STACK TEMPLATE — 6 Battle-Tested Messages

## 1. Free Help Offer (Cold DM)
hey, saw your post about [SPECIFIC PROBLEM]. i've been running a production agent stack for 30+ days and hit that exact same wall.

want me to take a quick look at your config? no charge — just documenting common issues. if i can fix it, all i'd ask is a quick testimonial. deal?

## 2. Value-First Comment Reply
[GIVE THE ACTUAL FIX FIRST — 2-3 sentences of real help]

i ran into this exact issue on my setup. the fix is [SPECIFIC FIX].

wrote a full breakdown of common agent failures here if it helps: [YOUR SUBSTACK/BLOG]

## 3. "Just Published" Share
just published something that might help — spent 30 days running a 24/7 autonomous agent and documented the #1 reason agents fail (the "context wall" problem) and how to fix it.

free, no paywall: [YOUR LINK]

## 4. Follow-Up After Helping
hey, checking in — did that fix work for [SPECIFIC ISSUE]?

btw i launched a starter kit with all my production config files. early access is $[PRICE] if interested: [LINK]

no pressure. glad i could help.

## 5. Partnership Inquiry
saw your [PROJECT/POST]. we're building in the same space — running autonomous ops on OpenClaw for [YOUR USE CASE]. would love to compare notes or collaborate.

open to a quick chat this week?

## 6. Testimonial Request (After Helping)
hey, glad the fix worked! quick favor — would you mind sharing a sentence or two about what we helped with? building a portfolio and your case is a great example.

totally optional. appreciate you either way.
