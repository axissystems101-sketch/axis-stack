# Sales Pipeline Tracker
# ⚡ AXIS STACK TEMPLATE

| Date | Source | Lead | Need | Outreach | Status |
|------|--------|------|------|----------|--------|
| YYYY-MM-DD | Reddit/X/Email | Name/Username | What they need | What you sent | Lead/Warm/Hot/Closed |
